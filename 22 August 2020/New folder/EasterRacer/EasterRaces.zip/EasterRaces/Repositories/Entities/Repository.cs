﻿using EasterRaces.Repositories.Contracts;

namespace EasterRaces.Repositories.Entities
{
    public abstract class Repository : IRepository<T>
    {
        
    }
}